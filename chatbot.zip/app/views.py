from django.shortcuts import render , get_object_or_404
from rest_framework.viewsets import ModelViewSet
from .models import ChatbotFileURL , ChatbotDesign , QA , chatbot , WebsiteFileURL
from Auth.models import Auth
from .serializers import ChatbotFileURLSerializers , ChatbotDesignSerializer , ChatSerializer , chatbotserializer , WebURLSerializers
from .Crud import uploadfile , textChunks , VectorEmbeddings
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
import os
from django.conf import settings
import ast
from rest_framework.decorators import action
import datetime


class chatbotView(ModelViewSet):
    queryset = chatbot.objects.all()
    serializer_class = chatbotserializer

    def create(self, request):
        try:
            AuthID = request.data.get("AuthID")
            
            AuthInstance=Auth.objects.filter(ID=AuthID).exists()
            if AuthInstance is None:
                return Response({"detail": "User does not exist"}, status=status.HTTP_401_UNAUTHORIZED)

            serializer = chatbotserializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"detail": "Chatbot created successfully"}, status=status.HTTP_201_CREATED)
            
            return Response({"errors": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def destroy(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)



class CreateChatbotDesign(ModelViewSet):
    queryset = ChatbotDesign.objects.all()
    serializer_class = ChatbotDesignSerializer

    def create(self, request):
        try:  
            chatbotID_id = request.data.get('chatbotID')
            chatbotIDInstance = chatbot.objects.filter(ID=chatbotID_id).first()
            if chatbotIDInstance is None:
                return Response({"detail": "Chatbot does not exist"}, status=status.HTTP_404_NOT_FOUND)
             
            ChatbotDesignIDInstance = chatbotIDInstance.ID
            ChatBotDesignChatbotID = ChatbotDesign.objects.filter(chatbotID=ChatbotDesignIDInstance).first()
            if ChatBotDesignChatbotID is not None:
                return Response({"detail": f"{chatbotID_id} Chatbot design already exists"}, status=status.HTTP_409_CONFLICT)

            serializer = ChatbotDesignSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"details": "Chatbot design created successfully"}, status=status.HTTP_201_CREATED)
            return Response({"details": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    
    def update(self, request, pk):
        try:
            data = {
                "ChatbotName": request.data.get("ChatbotName"),
                "ChatbotAssistant": request.data.get("ChatbotAssistant"),
                "ChatbotColor": request.data.get("ChatbotColor"),
                "WidgetIcon": request.data.get("WidgetIcon"),
                "WidgetIconColor": request.data.get("WidgetIconColor"),
                "LogoURL": request.data.get("LogoURL"),
                "Avatar": request.data.get("Avatar"),
                "AvatarURL": request.data.get("AvatarURL"),
                "WelcomeMessage": request.data.get("WelcomeMessage"),
                "UnableRelevantResponse": request.data.get("UnableRelevantResponse"),
                "ToolTipsMessage": request.data.get("ToolTipsMessage"),
                "QuickPrompt": request.data.get("QuickPrompt"),
                "StartTime": request.data.get("StartTime"),
                "EndTime": request.data.get("EndTime"),
                "WorkingDays": request.data.get("WorkingDays"),
                "EmailNotifMessage": request.data.get("EmailNotifMessage")
            }
            
            print(pk)
            chatbot_design = ChatbotDesign.objects.filter(chatbotID_id=pk).first()
            if chatbot_design is None:
                return Response({"detail": "Chatbot design does not exist"}, status=status.HTTP_404_NOT_FOUND)

            update_serializer = ChatbotDesignSerializer(instance=chatbot_design, data=data, partial=True)
            if update_serializer.is_valid():
                update_serializer.save()
                return Response({"detail": "Chatbot design updated successfully"}, status=status.HTTP_200_OK)

            return Response({"detail": update_serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def destroy(self , request , pk):

        try:
            chatbot_design = ChatbotDesign.objects.filter(chatbotID_id=pk).first()
            
            if chatbot_design is None:
                    return Response({"detail": "Chatbot design does not exist"}, status=status.HTTP_404_NOT_FOUND)
            
            chatbot_design.delete()
            return  Response({"delete" : f"{chatbot_design.chatbotID} Delete successfully"} , status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)
    
    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)


class ChatbotFileURLView(ModelViewSet):
    queryset = ChatbotFileURL.objects.all()
    serializer_class = ChatbotFileURLSerializers

    def create(self, request):
        try:
            FilePath = request.data.get('FilePath')
            chatbotDesignID = request.data.get("chatbotDesignID")
            URLPath = request.data.get("URLPath")


            ChatbotInstance = chatbot.objects.filter(ID=chatbotDesignID).first()
            print(ChatbotInstance)
            if ChatbotInstance is None:
                return Response({"detail": "Chatbot  does not exist"}, status=status.HTTP_401_UNAUTHORIZED)
            
            ChatbotDesignInstance = ChatbotDesign.objects.filter(chatbotID_id=ChatbotInstance.ID).first()
            if ChatbotDesignInstance is None:
                return Response({"detail": "Chatbot  Design does not exist"}, status=status.HTTP_401_UNAUTHORIZED)
            
            print(ChatbotDesignInstance.ID)
            chatbot_dir = f"static/files/{chatbotDesignID}/"
            os.makedirs(chatbot_dir, exist_ok=True)
            
            if FilePath and not URLPath:
                ChatbotFileURLInstance = ChatbotFileURL.objects.filter(chatbotDesignID=ChatbotDesignInstance.ID).first()
                print(ChatbotFileURLInstance)
                if ChatbotFileURLInstance is None:
                    file_paths = []
                    file_path = f"{chatbot_dir}{FilePath}"
                    with open(file_path, 'wb+') as destination:
                        for chunk in FilePath.chunks():
                                destination.write(chunk)
                    file_paths.append(file_path)
                    serializer = ChatbotFileURLSerializers(data={
                        'chatbotDesignID': ChatbotDesignInstance.ID,
                        'FilePath': file_paths
                    })

                    if serializer.is_valid():
                        serializer.save()
                        return Response({"detail": "New File Record saved in Chatbot successfully", "FilePathURL": file_paths}, status=status.HTTP_200_OK)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                else:
                    InitialFilePathList = ChatbotFileURLInstance.FilePath
                    FinalInitialFilePathList = ast.literal_eval(InitialFilePathList)

                    file_path = f"{chatbot_dir}{FilePath}"
                    if file_path in InitialFilePathList:
                            return Response({"detail": f"The file {file_path} already exists in the list."}, status=status.HTTP_400_BAD_REQUEST)
                    with open(file_path, 'wb+') as destination:
                        for chunk in FilePath.chunks():
                            destination.write(chunk)
                    FinalInitialFilePathList.append(file_path)

                    ChatbotFileURLInstance.FilePath = FinalInitialFilePathList
                    ChatbotFileURLInstance.save()

                    return Response({"detail": "File saved successfully", "FilePathURL": FinalInitialFilePathList}, status=status.HTTP_200_OK)
            
            elif not FilePath and URLPath:
                ChatbotWebURLInstance = WebsiteFileURL.objects.filter(chatbotDesignID=ChatbotDesignInstance.ID).first()
                print(ChatbotWebURLInstance)
                if ChatbotWebURLInstance is None:
                    URL_paths = []
                    
                    URL_paths.append(URLPath)
                    
                    print(URL_paths)
                    WebsiteFileURL_data = WebURLSerializers(data={
                        'chatbotDesignID': ChatbotDesignInstance.ID,
                        'WebURL': URL_paths
                    })
                    if WebsiteFileURL_data.is_valid():
                        WebsiteFileURL_data.save()
                        return Response({"detail": "URL Save Sucessfully", "WEBPathURL": URL_paths}, status=status.HTTP_200_OK)
                    return Response({"detail" : WebsiteFileURL_data.errors} , status=status.HTTP_401_UNAUTHORIZED)
                
                InitialURLPathList = ChatbotWebURLInstance.WebURL
                print(type(InitialURLPathList))
            
                if URLPath in InitialURLPathList:
                        return Response({"detail": f"The URL {URLPath} already exists in the list."}, status=status.HTTP_400_BAD_REQUEST)
                
                InitialURLPathList.append(URLPath)

                ChatbotWebURLInstance.WebURL = InitialURLPathList
                ChatbotWebURLInstance.save()

                return Response({"detail" : "URL Save Sucessfully"} , status=status.HTTP_200_OK)                
                
            elif FilePath and URLPath:
                return Response({"detail": "Just one Resourse use at a time File or URL"}, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({"detail": "File or URL does not provide"}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        

    @action(detail=True, methods=['get'], url_path='file-paths')
    def retrieve_file_paths(self, request, pk=None):
        try:
            chatbot_file_url_record = ChatbotFileURL.objects.get(pk=pk)
            file_paths = ast.literal_eval(chatbot_file_url_record.FilePath)

            file_details = []
            for file_path in file_paths:
                if os.path.exists(file_path):
                    file_size = os.path.getsize(file_path)
                    file_size_kb = file_size / 1024  # Convert to KB
                    file_name = os.path.basename(file_path)

                    file_creation_time = datetime.datetime.fromtimestamp(os.path.getctime(file_path)).strftime('%Y-%m-%d %I:%M:%S %p')

                    file_details.append({
                        'file_name': file_name,
                        'file_path': file_path,
                        'file_size': f"{round(file_size_kb, 2)} kb" , 
                        'Last_Update': file_creation_time,

                    })
                else:
                    file_details.append({
                        'file_name': os.path.basename(file_path),
                        'file_path': file_path,
                        'file_size': 'File not found',
                        'Last_Update': "N/A",

                    })

            response_data = {
                'ID': chatbot_file_url_record.ID,
                'FileDetails': file_details,
            }
            return Response(response_data, status=status.HTTP_200_OK)
        except ChatbotFileURL.DoesNotExist:
            return Response({"detail": "Record not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=['get'], url_path='web-urls')
    def retrieve_web_urls(self, request, pk=None):
        try:
            website_file_url_record = WebsiteFileURL.objects.get(pk=pk)
            web_urls = website_file_url_record.WebURL

            response_data = {
                'ID': website_file_url_record.ID,
                'WebURL': web_urls,
            }
            return Response(response_data, status=status.HTTP_200_OK)
        except WebsiteFileURL.DoesNotExist:
            return Response({"detail": "Record not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    @action(detail=True, methods=['delete'], url_path='delete-file')
    def delete_file(self, request, pk=None):
        try:
            file_name = request.data.get('file_name')
            if not file_name:
                return Response({"detail": "file_name is required"}, status=status.HTTP_400_BAD_REQUEST)

            chatbot_file_url_record = ChatbotFileURL.objects.get(pk=pk)
            file_paths = ast.literal_eval(chatbot_file_url_record.FilePath)

            file_path_to_delete = None
            for file_path in file_paths:
                if os.path.basename(file_path) == file_name:
                    file_path_to_delete = file_path
                    break

            if file_path_to_delete and os.path.exists(file_path_to_delete):
                os.remove(file_path_to_delete)  # Delete the file from the file system
                file_paths.remove(file_path_to_delete)  # Remove the file path from the list
                chatbot_file_url_record.FilePath = str(file_paths)
                chatbot_file_url_record.save()  # Save the updated record

                return Response({"detail": "File deleted successfully"}, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "File not found or does not exist"}, status=status.HTTP_404_NOT_FOUND)

        except ChatbotFileURL.DoesNotExist:
            return Response({"detail": "Record not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    @action(detail=True, methods=['delete'], url_path='delete-url')
    def delete_url(self, request, pk=None):
        try:
            url_to_delete = request.data.get('URLPath')
            print(url_to_delete)
            if not url_to_delete:
                return Response({"detail": "url is required"}, status=status.HTTP_400_BAD_REQUEST)

            website_file_url_record = WebsiteFileURL.objects.get(pk=pk)
            web_urls = website_file_url_record.WebURL

            if url_to_delete in web_urls:
                web_urls.remove(url_to_delete)
                website_file_url_record.WebURL = web_urls
                website_file_url_record.save()  # Save the updated record

                return Response({"detail": "URL deleted successfully"}, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "URL not found in the list"}, status=status.HTTP_404_NOT_FOUND)

        except WebsiteFileURL.DoesNotExist:
            return Response({"detail": "Record not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ChatView(ModelViewSet):
    queryset=QA.objects.all()
    serializer_class = ChatSerializer

    def create(self , request):
        try:
            ChatbotID=request.data.get("ChatbotID")
            Question=request.data.get("Question")

            ChatbotFileURLInstance = ChatbotFileURL.objects.filter(chatbotDesignID=ChatbotID).first()
            print(ChatbotFileURLInstance)
            FilesList=ChatbotFileURLInstance.FilePath
            FilesList = eval(FilesList)

            # Extract file names from paths and print
            for file_path in FilesList:
                print(file_path)
                documents=uploadfile(file_path)
                Chunks=textChunks(documents)
                db=VectorEmbeddings(Chunks , Question)
                print(db.content)

            return Response({"Question" :Question  ,"Answer" : db.content} , status=200)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

