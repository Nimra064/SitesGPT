from .models import Auth , OTP
from rest_framework import serializers
import re



# class AuthSerializer(serializers.ModelSerializer):
#     class Meta:
#         model=Auth
#         fields=['Email' , 'Password' , 'UserName']

#         extra_kwargs = {
#             'Email': {'validators': [serializers.EmailField().run_validation]}
#         }

class AuthSerializer(serializers.ModelSerializer):
    class Meta:
        model = Auth
        fields = ['Email', 'Password', 'UserName']


class LoginSerializer(serializers.Serializer):
    Email = serializers.EmailField(max_length=50, required=True)
    Password = serializers.CharField(write_only=True, required=True)



class OTPSerializer(serializers.ModelSerializer):
    class Meta:
        model=OTP
        fields=['OTP' , 'CreatedAt' , 'UpdatedAt']