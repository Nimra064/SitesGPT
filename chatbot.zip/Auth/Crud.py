import random
import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

def generate_otp(length): 
    digits = string.digits  
    otp = ''.join(random.choice(digits) for _ in range(length))
    DateTime=datetime.now()
    return otp , DateTime


def send_otp_email(Email ,OTP):
    sender_email = "Sitesgptchatbot@gmail.com"  
    sender_password = "xdwc qsjf cala ewyj" 
    smtp_server = "smtp.gmail.com"         
    smtp_port = 587                           

    # Compose the message
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = Email
    message["Subject"] = "Your OTP"

    body = f"Your OTP is: {OTP}. This OTP is usefull just for 30 Seconds."

    message.attach(MIMEText(body, "plain"))

    try:
        # Connect to the SMTP server and send the email
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()  # Start TLS encryption
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, Email, message.as_string())
        print("OTP sent successfully.")
    except smtplib.SMTPConnectError as e:
        print(f"Failed to connect to the SMTP server: {e}")


# def verify_otp(otp, generated_time):
#     current_time = datetime.now()
#     if (current_time - generated_time).total_seconds() <= 5:
#         return True
#     else:
#         return False
