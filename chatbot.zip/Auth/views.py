from rest_framework import status
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from django.contrib.auth.hashers import make_password , check_password
from .models import Auth , OTP
from .serializer import AuthSerializer , LoginSerializer , OTPSerializer
from .utils import generate_jwt_token  
from rest_framework.permissions import IsAuthenticated 
from .Crud import generate_otp , send_otp_email
import datetime




class RegisterView(ModelViewSet):
    queryset = Auth.objects.all()
    serializer_class = AuthSerializer

    def create(self, request):
        try:
            UserName = request.data.get("UserName")
            Email = request.data.get("Email")
            Password = request.data.get("Password")

            if Auth.objects.filter(Email=Email).exists():
                return Response({"detail": "Email already exists"}, status=status.HTTP_400_BAD_REQUEST)
            otp_length = 5
            otp, date_time = generate_otp(length=otp_length)
            send_otp_email(Email, otp)
            hashed_password = make_password(Password)
            register_data = {"UserName": UserName, "Email": Email, "Password": hashed_password}

            serializer = AuthSerializer(data=register_data)
            if serializer.is_valid():
                user = serializer.save()
                print(user)
                if user is not None:
                    otp_data = OTP(OTP=otp, CreatedAt=date_time, UpdatedAt=date_time)
                    otp_data.save()

                    token = generate_jwt_token(Email)
                    return Response({"detail": "Registered successfully", "Token": token}, status=status.HTTP_201_CREATED)
            else:
                return Response({"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def destroy(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)


class VerifyOTP(ModelViewSet):
    queryset = OTP.objects.all()
    serializer_class = OTPSerializer

    def create(self, request):
        OTPInput = request.data.get('OTP')
        
        try:
            OTPInstance = OTP.objects.filter(OTP=OTPInput).first()
            if OTPInstance is None:
                return Response({"detail" : "OTP is not Valid"} , status=status.HTTP_400_BAD_REQUEST)

            CreatedAt = OTPInstance.CreatedAt
            CurrentTime = datetime.datetime.now(datetime.timezone.utc)
            TimeSeconds=(CurrentTime - CreatedAt).total_seconds()
            print(TimeSeconds)
            if  TimeSeconds <= 1800:
                return Response({"detail": "OTP Verified Successfully"}, status=status.HTTP_200_OK)
            OTPInstancID=OTPInstance.ID
            Auth.objects.filter(ID=OTPInstancID).delete()
            OTP.objects.filter(ID=OTPInstancID).delete()
            return Response({"detail": "OTP Expired"}, status=status.HTTP_400_BAD_REQUEST)
            
        except ValueError as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"detail": "An error occurred: " + str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def destroy(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)



class Login(ModelViewSet):
    queryset = Auth.objects.all()
    serializer_class = LoginSerializer
    # permission_classes = [permissions.IsAuthenticated]

    def create(self, request):
        try:
            Email = request.data.get("Email")
            Password = request.data.get("Password")

            LoginUser=Auth.objects.filter(Email=Email).first()
            if LoginUser is None:
                return Response({"detail" : "User Does not exist"} , status=status.HTTP_400_BAD_REQUEST)
            
            DBPassword=LoginUser.Password
            VarifyPassword=check_password(Password , DBPassword)
            if VarifyPassword:
                Token=generate_jwt_token(Email)
                return Response({"detail" : "Login in Sucessfully" , "Token" : Token}  , status=200)
            return Response({"detail": "Password does not correct"}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def destroy(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)