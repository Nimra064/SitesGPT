from rest_framework import routers
from .views import RegisterView , Login , VerifyOTP

router = routers.DefaultRouter()

router.register('SignUp', RegisterView, basename='signup')
router.register('Login', Login, basename='Login')
router.register('OTP', VerifyOTP, basename='OTP')




urlpatterns = router.urls