from django.db import models

# Create your models here.

class Auth(models.Model):
    ID = models.AutoField(primary_key=True)
    UserName=models.CharField(max_length=255 , blank=False)
    Email = models.EmailField(max_length=50, blank=False)
    Password = models.CharField(max_length=128 , blank=False)  

    def __str__(self):
        return self.Email



class OTP(models.Model):
    ID = models.AutoField(primary_key=True)
    OTP = models.CharField(max_length=10, blank=False)
    CreatedAt = models.DateTimeField(auto_now_add=True)
    UpdatedAt = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.OTP


class Profile(models.Model):
    ID = models.AutoField(primary_key=True)
    UserID = models.ForeignKey(Auth, on_delete=models.CASCADE)
    FirstName = models.CharField(max_length=50, blank=False)
    LastName = models.CharField(max_length=50, blank=False)
    BusinessName = models.CharField(max_length=255, blank=False)

    def __str__(self):
        return f'{self.FirstName} {self.LastName}'
