from rest_framework import serializers
from .models import ChatbotFileURL , ChatbotDesign , QA , chatbot , WebsiteFileURL , Chat


class chatbotserializer(serializers.ModelSerializer):

    class Meta:
        model=chatbot
        fields='__all__'



class ChatbotFileURLSerializers(serializers.ModelSerializer):
        
    FilePath = serializers.ListField(child=serializers.CharField(max_length=255))
    
    class Meta:
        model=ChatbotFileURL
        fields="__all__"


class WebURLSerializers(serializers.ModelSerializer):
        
    
    class Meta:
        model=WebsiteFileURL
        fields="__all__"


class ChatbotDesignSerializer(serializers.ModelSerializer):
    class Meta:
        model=ChatbotDesign
        fields='__all__'

    def to_internal_value(self, data):
        if self.instance and 'chatbotID' in data:
            data.pop('chatbotID')  # Remove chatbotID from update data
        return super().to_internal_value(data)



class CreateChatSerializer(serializers.ModelSerializer):
    class Meta:
        model= Chat 
        fields='__all__'

class ChatSerializer(serializers.ModelSerializer):
    class Meta:
        model=QA
        fields='__all__'