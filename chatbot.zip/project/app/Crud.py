from langchain_community.document_loaders.csv_loader import CSVLoader
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader, TextLoader, UnstructuredPowerPointLoader, UnstructuredExcelLoader, WebBaseLoader
from langchain_openai import OpenAIEmbeddings  # Updated import
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores.chroma import Chroma
from langchain_openai import ChatOpenAI
import os 
from langchain_community.document_loaders import UnstructuredHTMLLoader
from dotenv import load_dotenv
load_dotenv()


# Access the environment variable
openai_api_key = os.getenv("openai_api_key")
if not openai_api_key:
    raise ValueError("OpenAI API key not found in environment variables")

embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)

# embeddings = OpenAIEmbeddings(openai_api_key="sk-proj-Eo3RWZOitOS0GhEc90rgT3BlbkFJwubHddhhDjT5zOve6Mtm")

def uploadfile(file_path):
    try:
        if file_path.startswith('http'):
            loader = WebBaseLoader(file_path) 
        else:
            file_name = file_path.split('/')[-1]
            file_extension = file_name.split(".")[-1].lower()
            loader = None  
            if file_extension == 'pdf':
                loader = PyPDFLoader(file_path)
            elif file_extension == 'csv':
                loader = CSVLoader(file_path, encoding="utf-8", csv_args={'delimiter': ','})
            elif file_extension in ['doc', 'docx']:
                loader = Docx2txtLoader(file_path)
            elif file_extension == 'txt':
                loader = TextLoader(file_path)
            elif file_extension in ['ppt' , 'pptx']:
                loader = UnstructuredPowerPointLoader(file_path)
            elif file_extension in ['xlsx' , 'xls']:
                loader = UnstructuredExcelLoader(file_path)
            elif file_extension == 'html':
                loader = UnstructuredHTMLLoader(file_path)
            elif file_path.startswith('http'):
                loader = WebBaseLoader(file_path)       
        documents = loader.load()
        return documents
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return None





def textChunks(documents):
    try:
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=20)
        text_chunks = text_splitter.split_documents(documents)
        return text_chunks
    except Exception as e:
        print(f"An error occurred: {e}")
        return None



def VectorEmbeddings(chunks , query):
    try:
        # Initialize vector store
        vector_storage = Chroma(persist_directory="vectordb", embedding_function=embeddings)

        # Add chunks to vector store
        vector_storage.add_documents(chunks)

        # Perform similarity search
        docs = vector_storage.similarity_search(query, k=3)

        content = "\n".join([x.page_content for x in docs])

        qa_prompt = "Use the following pieces of context to answer the user's question. If you don't know the answer, just say that you don't know, don't try to make up an answer.\n----------------"
        input_text = qa_prompt + "\nContext:" + content + "\nUser question:\n" + query

        llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0, openai_api_key="sk-proj-Eo3RWZOitOS0GhEc90rgT3BlbkFJwubHddhhDjT5zOve6Mtm")

        # Prepare the input as a list of messages
        messages = [{"role": "system", "content": input_text}]

        # Get the response from the LLM
        response = llm.invoke(messages)

        return response

    except Exception as e:
        print(f"An error occurred: {e}")
        return None
