from django.shortcuts import render , get_object_or_404
from rest_framework.viewsets import ModelViewSet
from .models import ChatbotFileURL , ChatbotDesign , QA , chatbot , WebsiteFileURL , Chat
from Auth.models import Auth
from .serializers import ChatbotFileURLSerializers , ChatbotDesignSerializer , ChatSerializer , chatbotserializer , WebURLSerializers , CreateChatSerializer
from .Crud import uploadfile , textChunks , VectorEmbeddings
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from rest_framework_simplejwt.authentication import JWTAuthentication
import os
from django.conf import settings
import ast
from rest_framework.decorators import action
import datetime
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework.exceptions import AuthenticationFailed
import jwt



class chatbotView(ModelViewSet):
    queryset = chatbot.objects.all()
    serializer_class = chatbotserializer
    # authentication_classes = [JWTAuthentication]
    # permission_classes = [IsAuthenticated]

    def create(self, request):
        try:
            AuthID = request.data.get("AuthID")
            Avater= request.data.get("Avater")
    #         AuthEmail = request.data.get("Email")
    #         Role = request.data.get("Role")
    #         createAT= request.data.get("createAT")
    #         LastMessageAT = request.data.get("LastMessageAT")
    #         chats = requestmodels.IntegerField(default=0)
    # messages = models.IntegerField(default=0)
            
            AuthInstance=Auth.objects.filter(id=AuthID).first()
            print(AuthInstance)
            if AuthInstance is None:
                return Response({"detail": "User does not exist"}, status=status.HTTP_401_UNAUTHORIZED)
            Email=AuthInstance.Email
            print(Email)
            createAT=datetime.datetime.now()
            data={"AuthID" : AuthID , "Avater" : Avater ,"AuthEmail" : Email , "Role" : "Owner" , "createAT" : createAT ,  "chats" : 0 , "messages" : 0  }
            serializer = chatbotserializer(data=data)
            if serializer.is_valid():
                serializer.save()
                return Response({"detail": "Chatbot created successfully"}, status=status.HTTP_201_CREATED)
            
            return Response({"errors": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self, request, pk):
        try:

            AuthUser=Auth.objects.filter(id=pk).first()
            print(AuthUser)
            if AuthUser is None:
                return Response({"detail": "User does not exist"}, status=status.HTTP_401_UNAUTHORIZED)
        
            chatbot_instance = chatbot.objects.filter(AuthID=AuthUser.id)
            print(chatbot_instance)
            if chatbot_instance.exists():
                # Serialize the retrieved records
                serializer = chatbotserializer(chatbot_instance, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "No chatbot records found for this user"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


    def update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def destroy(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)



class CreateChatbotDesign(ModelViewSet):
    queryset = ChatbotDesign.objects.all()
    serializer_class = ChatbotDesignSerializer

    def create(self, request):
        try:  
            chatbotID_id = request.data.get('chatbotID')
            chatbotIDInstance = chatbot.objects.filter(ID=chatbotID_id).first()
            if chatbotIDInstance is None:
                return Response({"detail": "Chatbot does not exist"}, status=status.HTTP_404_NOT_FOUND)
             
            ChatbotDesignIDInstance = chatbotIDInstance.ID
            ChatBotDesignChatbotID = ChatbotDesign.objects.filter(chatbotID=ChatbotDesignIDInstance).first()
            if ChatBotDesignChatbotID is not None:
                return Response({"detail": f"{chatbotID_id} Chatbot design already exists"}, status=status.HTTP_409_CONFLICT)

            serializer = ChatbotDesignSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"details": "Chatbot design created successfully"}, status=status.HTTP_201_CREATED)
            return Response({"details": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    
    def update(self, request, pk):
        try:
            data = {
                "ChatbotName": request.data.get("ChatbotName"),
                "ChatbotAssistant": request.data.get("ChatbotAssistant"),
                "ChatbotColor": request.data.get("ChatbotColor"),
                "WidgetIcon": request.data.get("WidgetIcon"),
                "WidgetIconColor": request.data.get("WidgetIconColor"),
                "LogoURL": request.data.get("LogoURL"),
                "Avatar": request.data.get("Avatar"),
                "AvatarURL": request.data.get("AvatarURL"),
                "WelcomeMessage": request.data.get("WelcomeMessage"),
                "UnableRelevantResponse": request.data.get("UnableRelevantResponse"),
                "ToolTipsMessage": request.data.get("ToolTipsMessage"),
                "QuickPrompt": request.data.get("QuickPrompt"),
                "StartTime": request.data.get("StartTime"),
                "EndTime": request.data.get("EndTime"),
                "WorkingDays": request.data.get("WorkingDays"),
                "EmailNotifMessage": request.data.get("EmailNotifMessage")
            }
            
            print(pk)
            chatbot_design = ChatbotDesign.objects.filter(chatbotID_id=pk).first()
            if chatbot_design is None:
                return Response({"detail": "Chatbot design does not exist"}, status=status.HTTP_404_NOT_FOUND)

            update_serializer = ChatbotDesignSerializer(instance=chatbot_design, data=data, partial=True)
            if update_serializer.is_valid():
                update_serializer.save()
                return Response({"detail": "Chatbot design updated successfully"}, status=status.HTTP_200_OK)

            return Response({"detail": update_serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def destroy(self , request , pk):

        try:
            chatbot_design = ChatbotDesign.objects.filter(chatbotID_id=pk).first()
            
            if chatbot_design is None:
                    return Response({"detail": "Chatbot design does not exist"}, status=status.HTTP_404_NOT_FOUND)
            
            chatbot_design.delete()
            return  Response({"delete" : f"{chatbot_design.chatbotID} Delete successfully"} , status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)
    
    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)


class ChatbotFileURLView(ModelViewSet):
    queryset = ChatbotFileURL.objects.all()
    serializer_class = ChatbotFileURLSerializers

    def create(self, request):
        try:
            FilePath = request.data.get('FilePath')
            chatbotID = request.data.get("chatbotID")
            URLPath = request.data.get("URLPath")


            ChatbotInstance = chatbot.objects.filter(ID=chatbotID).first()
            print(ChatbotInstance)
            if ChatbotInstance is None:
                return Response({"detail": "Chatbot  does not exist"}, status=status.HTTP_401_UNAUTHORIZED)
            
            ChatbotDesignInstance = ChatbotDesign.objects.filter(chatbotID_id=ChatbotInstance.ID).first()
            if ChatbotDesignInstance is None:
                return Response({"detail": "Chatbot  Design does not exist"}, status=status.HTTP_401_UNAUTHORIZED)
            
            print(ChatbotDesignInstance.ID)
            chatbot_dir = f"static/files/{chatbotID}/"
            os.makedirs(chatbot_dir, exist_ok=True)
            
            if FilePath and not URLPath:
                ChatbotFileURLInstance = ChatbotFileURL.objects.filter(chatbotDesignID=ChatbotDesignInstance.ID).first()
                print(ChatbotFileURLInstance)
                if ChatbotFileURLInstance is None:
                    file_paths = []
                    file_path = f"{chatbot_dir}{FilePath}"
                    with open(file_path, 'wb+') as destination:
                        for chunk in FilePath.chunks():
                                destination.write(chunk)
                    file_paths.append(file_path)
                    serializer = ChatbotFileURLSerializers(data={
                        'chatbotID' : chatbotID,
                        'chatbotDesignID': ChatbotDesignInstance.ID,
                        'FilePath': file_paths
                    })

                    if serializer.is_valid():
                        serializer.save()
                        return Response({"detail": "New File Record saved in Chatbot successfully", "FilePathURL": file_paths}, status=status.HTTP_200_OK)
                    else:
                        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                else:
                    InitialFilePathList = ChatbotFileURLInstance.FilePath
                    FinalInitialFilePathList = ast.literal_eval(InitialFilePathList)

                    file_path = f"{chatbot_dir}{FilePath}"
                    if file_path in InitialFilePathList:
                            return Response({"detail": f"The file {file_path} already exists in the list."}, status=status.HTTP_400_BAD_REQUEST)
                    with open(file_path, 'wb+') as destination:
                        for chunk in FilePath.chunks():
                            destination.write(chunk)
                    FinalInitialFilePathList.append(file_path)

                    ChatbotFileURLInstance.FilePath = FinalInitialFilePathList
                    ChatbotFileURLInstance.save()

                    return Response({"detail": "File saved successfully", "FilePathURL": FinalInitialFilePathList}, status=status.HTTP_200_OK)
            
            elif not FilePath and URLPath:
                ChatbotWebURLInstance = WebsiteFileURL.objects.filter(chatbotDesignID=ChatbotDesignInstance.ID).first()
                print(ChatbotWebURLInstance)
                if ChatbotWebURLInstance is None:
                    URL_paths = []
                    
                    URL_paths.append(URLPath)
                    
                    print(URL_paths)
                    WebsiteFileURL_data = WebURLSerializers(data={
                        'chatbotID' : chatbotID,
                        'chatbotDesignID': ChatbotDesignInstance.ID,
                        'WebURL': URL_paths
                    })
                    if WebsiteFileURL_data.is_valid():
                        WebsiteFileURL_data.save()
                        return Response({"detail": "URL Save Sucessfully", "WEBPathURL": URL_paths}, status=status.HTTP_200_OK)
                    return Response({"detail" : WebsiteFileURL_data.errors} , status=status.HTTP_401_UNAUTHORIZED)
                
                InitialURLPathList = ChatbotWebURLInstance.WebURL
                print(type(InitialURLPathList))
            
                if URLPath in InitialURLPathList:
                        return Response({"detail": f"The URL {URLPath} already exists in the list."}, status=status.HTTP_400_BAD_REQUEST)
                
                InitialURLPathList.append(URLPath)

                ChatbotWebURLInstance.WebURL = InitialURLPathList
                ChatbotWebURLInstance.save()

                return Response({"detail" : "URL Save Sucessfully"} , status=status.HTTP_200_OK)                
                
            elif FilePath and URLPath:
                return Response({"detail": "Just one Resourse use at a time File or URL"}, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({"detail": "File or URL does not provide"}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        

    @action(detail=True, methods=['get'], url_path='file-paths')
    def retrieve_file_paths(self, request, pk=None):
        try:
            chatbot_file_url_record = ChatbotFileURL.objects.get(pk=pk)
            file_paths = ast.literal_eval(chatbot_file_url_record.FilePath)

            file_details = []
            for file_path in file_paths:
                if os.path.exists(file_path):
                    file_size = os.path.getsize(file_path)
                    file_size_kb = file_size / 1024  # Convert to KB
                    file_name = os.path.basename(file_path)

                    file_creation_time = datetime.datetime.fromtimestamp(os.path.getctime(file_path)).strftime('%Y-%m-%d %I:%M:%S %p')

                    file_details.append({
                        'file_name': file_name,
                        'file_path': file_path,
                        'file_size': f"{round(file_size_kb, 2)} kb" , 
                        'Last_Update': file_creation_time,

                    })
                else:
                    file_details.append({
                        'file_name': os.path.basename(file_path),
                        'file_path': file_path,
                        'file_size': 'File not found',
                        'Last_Update': "N/A",

                    })

            response_data = {
                'ID': chatbot_file_url_record.ID,
                'FileDetails': file_details,
            }
            return Response(response_data, status=status.HTTP_200_OK)
        except ChatbotFileURL.DoesNotExist:
            return Response({"detail": "Record not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=['get'], url_path='web-urls')
    def retrieve_web_urls(self, request, pk=None):
        try:
            website_file_url_record = WebsiteFileURL.objects.get(pk=pk)
            web_urls = website_file_url_record.WebURL

            response_data = {
                'ID': website_file_url_record.ID,
                'WebURL': web_urls,
            }
            return Response(response_data, status=status.HTTP_200_OK)
        except WebsiteFileURL.DoesNotExist:
            return Response({"detail": "Record not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    @action(detail=True, methods=['delete'], url_path='delete-file')
    def delete_file(self, request, pk=None):
        try:
            file_name = request.data.get('file_name')
            if not file_name:
                return Response({"detail": "file_name is required"}, status=status.HTTP_400_BAD_REQUEST)

            chatbot_file_url_record = ChatbotFileURL.objects.get(pk=pk)
            file_paths = ast.literal_eval(chatbot_file_url_record.FilePath)

            file_path_to_delete = None
            for file_path in file_paths:
                if os.path.basename(file_path) == file_name:
                    file_path_to_delete = file_path
                    break

            if file_path_to_delete and os.path.exists(file_path_to_delete):
                os.remove(file_path_to_delete)  # Delete the file from the file system
                file_paths.remove(file_path_to_delete)  # Remove the file path from the list
                chatbot_file_url_record.FilePath = str(file_paths)
                chatbot_file_url_record.save()  # Save the updated record

                return Response({"detail": "File deleted successfully"}, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "File not found or does not exist"}, status=status.HTTP_404_NOT_FOUND)

        except ChatbotFileURL.DoesNotExist:
            return Response({"detail": "Record not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    @action(detail=True, methods=['delete'], url_path='delete-url')
    def delete_url(self, request, pk=None):
        try:
            url_to_delete = request.data.get('URLPath')
            print(url_to_delete)
            if not url_to_delete:
                return Response({"detail": "url is required"}, status=status.HTTP_400_BAD_REQUEST)

            website_file_url_record = WebsiteFileURL.objects.get(pk=pk)
            web_urls = website_file_url_record.WebURL

            if url_to_delete in web_urls:
                web_urls.remove(url_to_delete)
                website_file_url_record.WebURL = web_urls
                website_file_url_record.save()  # Save the updated record

                return Response({"detail": "URL deleted successfully"}, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "URL not found in the list"}, status=status.HTTP_404_NOT_FOUND)

        except WebsiteFileURL.DoesNotExist:
            return Response({"detail": "Record not found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class CreateChatView(ModelViewSet):
    queryset=Chat.objects.all()
    serializer_class = CreateChatSerializer

    def create(self, request):
        try:
            ChatbotID = request.data.get("chatbotID")

            ChatbotInstance = chatbot.objects.filter(ID=ChatbotID).first()
            print(ChatbotInstance)
            if ChatbotInstance is None:
                return Response({"detail": "Chatbot  does not exist"}, status=status.HTTP_401_UNAUTHORIZED)
            
            serlializer=CreateChatSerializer(data=request.data)
            if serlializer.is_valid():
                serlializer.save()

                return Response({"detail": "Chat Record Save Sucessfully"}, status=200)
            
            return Response({"detail": serlializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)




class ChatView(ModelViewSet):
    queryset=QA.objects.all()
    serializer_class = ChatSerializer


    def create(self, request):
        try:
            ChatbotID = request.data.get("ChatbotID")
            Question = request.data.get("Question")

            ChatbotFileURLInstance = ChatbotFileURL.objects.filter(chatbotID=ChatbotID).first()
            WebsiteFileURLInstance = WebsiteFileURL.objects.filter(chatbotID=ChatbotID).first()

            all_chunks = []

            # Process file paths
            if ChatbotFileURLInstance is not None:
                FilesList = ChatbotFileURLInstance.FilePath
                FilesList = eval(FilesList)

                for file_path in FilesList:
                    print(file_path)
                    documents = uploadfile(file_path)
                    Chunks = textChunks(documents)
                    all_chunks.extend(Chunks)

            # Process website URLs
            if WebsiteFileURLInstance is not None:
                WebURLsList = WebsiteFileURLInstance.WebURL
                WebURLsList = eval(WebURLsList)

                for web_url in WebURLsList:
                    documents = uploadfile(web_url)
                    Chunks = textChunks(documents)
                    all_chunks.extend(Chunks)

            db = VectorEmbeddings(all_chunks, Question)
            if db is not None:
                print(db)
                ChatbotInstance = chatbot.objects.filter(ID=ChatbotID).first()
                print(ChatbotInstance)
                if ChatbotInstance:
                    ChatbotInstance.LastMessageAT = datetime.datetime.now()
                    ChatbotInstance.chats = ChatbotID
                    ChatbotInstance.messages += 1
                    ChatbotInstance.save()

                    data = {
                        "Question": Question,
                        "Answer": db.content  # Replace with your actual answer content
                    }

                    ChatInstance = Chat.objects.filter(chatbotID=ChatbotInstance).first()
                    print(ChatInstance)
                    if ChatInstance is not None:
                        QAInstance = QA.objects.filter(chatID=ChatInstance).first()
                        if QAInstance is not None:
                            chathistory = QAInstance.QAL 
                            chathistory.append(data)
                            QAInstance.QAL = chathistory
                            QAInstance.save()

                        else:
                            QAInstance = QA(chatID=ChatInstance, QAL=[data])
                            QAInstance.save()
                    
                        return Response({"Question": Question, "Answer": db.content}, status=200)
                
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


    def retrieve(self, request, pk):
        try:
            # Retrieve the chatbot record with the given primary key
            chatbot_instance = chatbot.objects.filter(ID=pk).first()
            
            if chatbot_instance:
                ChatInstance = Chat.objects.filter(chatbotID=chatbot_instance).first()

                # Fetch all QA records associated with the ChatbotID
                QAInstances = QA.objects.filter(chatID=ChatInstance)

                response_data = {
                    "Chatbot": {
                        "ID": chatbot_instance.ID,
                        "LastMessageAT": chatbot_instance.LastMessageAT,
                        "chats": chatbot_instance.chats,
                        "messages": chatbot_instance.messages
                    },
                    "QA": []
                }

                for qa_instance in QAInstances:
                    response_data["QA"].append({
                        "QA": qa_instance.QAL
                    })

                return Response(response_data, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "Not found"}, status=status.HTTP_404_NOT_FOUND)
        
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



class LogoutView(ModelViewSet):

    def create(self, request):
        refresh_token = request.data.get("refresh")
        if refresh_token:
            try:
                token = RefreshToken(refresh_token)
                token.blacklist()
                return Response({"detail": "Successfully logged out."}, status=status.HTTP_205_RESET_CONTENT)
            except Exception as e:
                return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"detail": "Refresh token is required."}, status=status.HTTP_400_BAD_REQUEST)