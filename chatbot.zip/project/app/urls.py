from rest_framework import routers
from .views import CreateChatbotDesign , ChatbotFileURLView , ChatView , chatbotView , CreateChatView , LogoutView
# from .views import SellerCompanyOverviewView, SellerStartupFinancialsView, SellerAcquisitionDetailsView, StartupView, GetStartupsView

router = routers.DefaultRouter()
# router.register('SellerCompanyOverview', SellerCompanyOverviewView)

router.register(r'Chatbot', chatbotView, basename='Chatbot')
router.register(r'ChatbotDesign', CreateChatbotDesign, basename='ChatbotDesign')
router.register(r'ChatbotURL', ChatbotFileURLView, basename='ChatbotURL')
router.register(r'ChatView', ChatView, basename='ChatView')
router.register(r'CreateChat', CreateChatView, basename='CreateChatView')
router.register(r'Logout', LogoutView, basename='Logout')







urlpatterns = router.urls