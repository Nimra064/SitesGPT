from rest_framework import status
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from django.contrib.auth.hashers import make_password , check_password
from .models import Auth , ActivationCode
from .serializer import AuthSerializer , LoginSerializer , ActivationCodeSerializer
from .utils import generate_jwt_token  
from rest_framework.permissions import IsAuthenticated 




class RegisterView(ModelViewSet):
    queryset = Auth.objects.all()
    serializer_class = AuthSerializer

    def create(self, request):
        try:
            Username = request.data.get("Username")
            Email = request.data.get("Email")
            Password = request.data.get("Password")

            if Auth.objects.filter(Email=Email).exists():
                return Response({"detail": "Email already exists"}, status=status.HTTP_400_BAD_REQUEST)
            

            hashed_password = make_password(Password)
            register_data = {"Username": Username, "Email": Email, "Password": hashed_password}

            serializer = AuthSerializer(data=register_data)
            if serializer.is_valid():
                user = serializer.save()
                if user is not None:
                    token = generate_jwt_token(Email)
                    return Response({"detail": "Registered successfully", "Token": token}, status=status.HTTP_201_CREATED)
            else:
                return Response({"detail": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def destroy(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)


class ActivationCodeView(ModelViewSet):
    queryset = ActivationCode.objects.all()
    serializer_class = ActivationCodeSerializer

    def create(self, request):
        AuthID = request.data.get('AuthID')
        ActivationCode = request.data.get('ActivationCode')

        print(AuthID)
        
        try:
            ActivationCodeinstance="1234567890"
            if ActivationCodeinstance==ActivationCode:
                print(len(ActivationCodeinstance))
                register_data={"AuthID" : AuthID , "ActivationCode" : ActivationCode}
                serializer = ActivationCodeSerializer(data=register_data)
                if serializer.is_valid():
                    serializer.save()

                    return Response({"detail": "Activation Code Verified Successfully"}, status=status.HTTP_200_OK)
                return Response({"detail" : serializer.errors} , status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            Authinstance = Auth.objects.filter(ID=AuthID).first() 
            if Authinstance is not None:
                Authinstance.delete
                return Response({"detail": "Activation code does not correct"}, status=status.HTTP_401_UNAUTHORIZED)
        
        except Exception as e:
            return Response({"detail": "An error occurred: " + str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def destroy(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)




class Login(ModelViewSet):
    queryset = Auth.objects.all()
    serializer_class = LoginSerializer
    # permission_classes = [permissions.IsAuthenticated]

    def create(self, request):
        try:
            Email = request.data.get("Email")
            Password = request.data.get("Password")

            LoginUser=Auth.objects.filter(Email=Email).first()
            if LoginUser is None:
                return Response({"detail" : "User Does not exist"} , status=status.HTTP_400_BAD_REQUEST)
            
            DBPassword=LoginUser.Password
            VarifyPassword=check_password(Password , DBPassword)
            if VarifyPassword:
                Token=generate_jwt_token(Email)
                return Response({"detail" : "Login in Sucessfully" , "Token" : Token}  , status=200)
            return Response({"detail": "Password does not correct"}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def list(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def retrieve(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def partial_update(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def destroy(self , request):
        return Response({"detail": "Method not allowed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)